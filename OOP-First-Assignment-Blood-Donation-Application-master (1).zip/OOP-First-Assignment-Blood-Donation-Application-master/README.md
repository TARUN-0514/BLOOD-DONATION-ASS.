# OOP-First-Assignment-Blood-Donation-Application
The first assignment in our OOP course, by 20bcs006, 20bcs025

Open the MainMenu.py file for the application
Create an account or use user1 and pass1 to login
